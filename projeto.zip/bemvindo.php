<!DOCTYPE html>
<html>
<head>
    <title>Bem-vindo</title>
</head>
<body>
    <h1>Seja bem-vindo ao nosso sistema de armazenamento de ficheiros</h1>
    <p>
        Este sistema foi desenvolvido para organizar e armazenar:
        <ul>
            <li>Pautas escolares</li>
            <li>Imagens dos colegas durante as aulas</li>
            <li>Registros de actividades escolares</li>
        </ul>
    </p>
    <a href="index.php">Aceder ao CRUD</a>
</body>
</html>