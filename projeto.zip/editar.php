<?php
include 'conexao.php';
$id = $_GET['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $sql = "UPDATE pessoas SET nome='$nome', email='$email', telefone='$telefone' WHERE id=$id";
    $conn->query($sql);
    header('Location: index.php');
}
$sql = "SELECT * FROM pessoas WHERE id=$id";
$resultado = $conn->query($sql);
$pessoa = $resultado->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head><title>Editar Pessoa</title></head>
<body>
    <h2>Editar Pessoa</h2>
    <form method="POST">
        Nome: <input type="text" name="nome" value="<?= $pessoa['nome'] ?>" required><br>
        Email: <input type="email" name="email" value="<?= $pessoa['email'] ?>" required><br>
        Telefone: <input type="text" name="telefone" value="<?= $pessoa['telefone'] ?>" required><br>
        <input type="submit" value="Salvar">
    </form>
</body>
</html>