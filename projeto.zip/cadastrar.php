<?php
include 'conexao.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $sql = "INSERT INTO pessoas (nome, email, telefone) VALUES ('$nome', '$email', '$telefone')";
    $conn->query($sql);
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html>
<head><title>Cadastrar Pessoa</title></head>
<body>
    <h2>Cadastrar Pessoa</h2>
    <form method="POST">
        Nome: <input type="text" name="nome" required><br>
        Email: <input type="email" name="email" required><br>
        Telefone: <input type="text" name="telefone" required><br>
        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>