<?php
include 'conexao.php';
$sql = "SELECT * FROM pessoas";
$resultado = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head><title>Lista de Pessoas</title></head>
<body>
    <h2>Lista de Pessoas</h2>
    <a href="cadastrar.php">Cadastrar nova pessoa</a>
    <table border="1">
        <tr><th>ID</th><th>Nome</th><th>Email</th><th>Telefone</th><th>Ações</th></tr>
        <?php while($row = $resultado->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['nome'] ?></td>
            <td><?= $row['email'] ?></td>
            <td><?= $row['telefone'] ?></td>
            <td>
                <a href="editar.php?id=<?= $row['id'] ?>">Editar</a> |
                <a href="excluir.php?id=<?= $row['id'] ?>" onclick="return confirm('Tem certeza?')">Excluir</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>